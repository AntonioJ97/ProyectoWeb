package com.proyecto.service;

import com.proyecto.model.Product;
import com.proyecto.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Clase encargada de agregar,actualizar,borrar de la base de datos productos y
 * numero de productos,todos los productos de la base de datos
 * 
 * @Service: Indica a Spring que esta clase es un servicio
 * @Transactional: Permite realizar las transacciones con la base de datos
 */
@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    /**
     * Metodo que guarda en la base de datos un producto
     */
    @Override
    public Product saveProduct(final Product product) {
        productRepository.save(product);
        return product;
    }

    /**
     * Metodo que actualiza un producto en la base de datos
     */
    @Override
    public Product updateProduct(final Product product) {
        return productRepository.save(product);
    }

    /**
     * Metodo que elimina un producto de la base de datos
     */
    @Override
    public void deleteProduct(final Long productId) {
        productRepository.deleteById(productId);
    }

    /**
     * Metodo que permite obtener el numero de productos de la base de datos
     */
    @Override
    public Long numberOfProducts() {
        return productRepository.count();
    }

    /**
     * Metodo que permite obtener todos los productos
     */
    @Override
    public List<Product> findAllProducts() {
        return productRepository.findAll();
    }
}
