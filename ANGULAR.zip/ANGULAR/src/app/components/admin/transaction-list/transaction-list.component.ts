import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Transaction } from 'src/app/model/transaction';
import { AdminService } from 'src/app/services/admin.service';


@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css'],
})
export class TransactionListComponent implements OnInit {
  //array de Transacciones
  transactionList: Array<Transaction>;
  //Tabla de datos de angular material
  dataSource: MatTableDataSource<Transaction> = new MatTableDataSource();
  displayedColumns: string[] = ['id', 'usuario', 'producto'];
  // Uso la directiva de MatPaginator para usarla como paginacion de las transacciones
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //Directiva MatSort que se usara para ordenar por columna id, usuario o producto
  @ViewChild(MatSort) sort: MatSort;
  /**
   *
   *  Metodo constructor de la clase
   * @param adminService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   */
  constructor(private adminService: AdminService) {}
  /**
   * Metodo que se inicia justo despues del constructor
   */
  ngOnInit(): void {
    // Obtengo todas las transacciones
    this.findAllTransactions();
  }
  /**
   * Metodo que se ejecuta cuando la vista del componente se ha inicializado por completo.
   */
  ngAfterViewInit(): void {
    // Asigno el orden seleccionado por el usuario
    this.dataSource.sort = this.sort;
    // Asigno la pagina selccionada por el usuario
    this.dataSource.paginator = this.paginator;
  }
  /**
   * Metodo para obtener todas las transacciones
   */
  findAllTransactions(): void {
    this.adminService.findAllTransactions().subscribe((data) => {
      this.transactionList = data;
      this.dataSource = data;
    });
  }

}
