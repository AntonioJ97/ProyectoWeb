import { Role } from './role';
/**
 *  Clase que almacena los usuarios
 */
export class User {
  id: number;
  username = '';
  password = '';
  name = '';
  role: Role;
  token = '';
}
