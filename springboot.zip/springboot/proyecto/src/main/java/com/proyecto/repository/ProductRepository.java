package com.proyecto.repository;

import com.proyecto.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Interfaz usada para los servicios las cuales permitirá realizar la
 * actualizacion,eliminacion o agregacion de un producto El Long hace referencia
 * al tipo de dato del id de los productos
 */
public interface ProductRepository extends JpaRepository<Product, Long> {
}
