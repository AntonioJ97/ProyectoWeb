package com.proyecto.controller;

import com.proyecto.jwt.JwtTokenProvider;
import com.proyecto.model.Role;
import com.proyecto.model.Transaction;
import com.proyecto.model.User;
import com.proyecto.service.ProductService;
import com.proyecto.service.TransactionService;
import com.proyecto.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;

/**
 * Clase encargada de controlar las rutas de los usuarios Anotacion encargada de
 * indicar a spring que la clase es un controlador
 */
@RestController
public class UserController {

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private UserService userService;

    @Autowired
    private ProductService productService;

    @Autowired
    private TransactionService transactionService;

    /**
     * Metodo encargado de registrar a un usuario
     * 
     * @param user usuario a registrar
     * @return Devuelve la respuesta a angular
     */
    @PostMapping("/api/user/registration")
    public ResponseEntity<?> register(@RequestBody User user) {
        // compruebo el nombre del usuario para saber si no es null
        if (userService.findByUsername(user.getUsername()) != null) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        // asigno rol por defecto
        user.setRole(Role.USER);
        return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
    }

    /**
     * Metodo encargado de obtener el usuario
     * 
     * @param principal Interfaz encargada de representar al usuario o cualquier
     *                  entidad pudiendo ser individual o corporativa
     * @return Devuelve la respuesta a angular
     */
    @GetMapping("/api/user/login")
    public ResponseEntity<?> getUser(Principal principal) {
        // compruebo que principal no sea nulo
        if (principal == null) {
            return ResponseEntity.ok(principal);
        }
        // transformo principal a usuario con contraseña
        UsernamePasswordAuthenticationToken authenticationToken = (UsernamePasswordAuthenticationToken) principal;
        // asigno al usuario el nombre
        User user = userService.findByUsername(authenticationToken.getName());
        // le asigno el token al usuario
        user.setToken(tokenProvider.generateToken(authenticationToken));

        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    /**
     * Metodo que permite realizar una compra
     * 
     * @param transaction Transaccion a realizar
     * @return Devuelve la respuesta a angular
     */
    @PostMapping("/api/user/purchase")
    public ResponseEntity<?> purchaseProduct(@RequestBody Transaction transaction) {
        // asigno la fecha de la compra al dia
        transaction.setPurchaseDate(LocalDateTime.now());
        // se guarda la transaccion en la base de datos
        transactionService.saveTransaction(transaction);
        return new ResponseEntity<>(transaction, HttpStatus.CREATED);
    }

    /**
     * Metodo encargado de obtener todos los productos
     * 
     * @return Devuelve la respuesta a angular
     */
    @GetMapping("/api/user/products")
    public ResponseEntity<?> getAllProducts() {
        return new ResponseEntity<>(productService.findAllProducts(), HttpStatus.OK);
    }

    /**
     * Metodo encargado de obtener todas las compras
     * 
     * @return devuelve la respuesta a angular
     */
    @GetMapping("/api/user/transaction-all")
    public ResponseEntity<?> findAllTransactions() {
        return new ResponseEntity<>(transactionService.findAllTransactions(), HttpStatus.OK);
    }

}
