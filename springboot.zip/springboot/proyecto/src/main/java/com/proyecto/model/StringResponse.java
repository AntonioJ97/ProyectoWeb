package com.proyecto.model;

import lombok.Data;
/**
 * Clase que se usa para realizar la respuesta que se usara en el controller Admin
 */
@Data
public class StringResponse {
    private String response;

    public String getResponse() {
        return this.response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
