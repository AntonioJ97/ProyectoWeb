import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-admin-template',
  templateUrl: './admin-template.component.html',
  styleUrls: ['./admin-template.component.css'],
})
export class AdminTemplateComponent implements OnInit {
  // Propiedad donde se almacena el usuario logeado
  currentUser: User;
  /**
   * Constructor de la clase
   * @param userService Permite obtener el usuario actual
   * @param router Enrutamiento usado para navegar a la pagina login cuando el usuario se desconecte de la web
   */
  constructor(private userService: UserService, public router: Router) {
    //asigno a la variable el usuario logeado
    this.userService.currentUser.subscribe((data) => {
      this.currentUser = data;
    });
  }

  ngOnInit(): void {}
  //Metodo usado para cerrar la sesion del usuario
  logOut(): void {
    this.userService.logOut().subscribe((data) => {
      this.router.navigate(['/login']);
    });
  }
}
