package com.proyecto.repository;

import com.proyecto.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Interfaz usada para los servicios las cuales permitirá realizar la
 * actualizacion,eliminacion o agregacion del usuario El Long hace referencia al
 * tipo de dato del id del usuario
 */
public interface UserRepository extends JpaRepository<User, Long> {

    // Metodo que se implementara para encontrar el nombre de un usuario
    Optional<User> findByUsername(String username);
}
