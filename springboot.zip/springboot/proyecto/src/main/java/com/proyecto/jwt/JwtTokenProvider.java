package com.proyecto.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Esta clase se encargará de generar el token, obtener la autenticación,
 * validar el token o resolverlo.
 */
@Component
public class JwtTokenProvider {
    // Obtengo el valor del application properties y se lo asigno a la propiedad
    @Value("${app.jwt.secret}")
    private String jwtSecret;
    // Obtengo el valor del application properties y se lo asigno a la propiedad
    @Value("${app.jwt.token.prefix}")
    private String jwtTokenPrefix;
    // Obtengo el valor del application properties y se lo asigno a la propiedad
    @Value("${app.jwt.header.string}")
    private String jwtHeaderString;
    // Obtengo el valor del application properties y se lo asigno a la propiedad
    @Value("${app.jwt.expiration-in-ms}")
    private Long jwtExpirationInMs;

    /**
     * Metodo encargado de generar el token
     * 
     * @param auth
     * @return devuelve token
     */
    public String generateToken(Authentication auth) {
        // Obtengo el usuario autenticado y obtengo su rol
        String authorities = auth.getAuthorities().stream().map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining());
        // Devuelvo el token generado, usando las propiedades de la clase, usando el
        // algoritmo hs512
        return Jwts.builder().setSubject(auth.getName()).claim("roles", authorities)
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationInMs))
                .signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
    }

    /**
     * Metodo encargado de obtener la authentication que se usa en la clase
     * jwtauthorizationfilter
     * 
     * @param request Proporciona acceso a los datos de las cabeceras HTTP, cookies,
     *                parámetros pasados por el usuario,
     * @return el usuario autenticado
     */
    public Authentication getAuthentication(HttpServletRequest request) {
        // asigno el token
        String token = resolveToken(request);
        // compruebo si es nulo
        if (token == null) {
            return null;
        }
        // comprueba que el jwt es firmado que se compone por:
        // Codificación en Base64 de header.
        // Codificación en Base64 de payload.
        // Un secreto, establecido por la aplicación.
        Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
        // Obtengo el usuario
        String username = claims.getSubject();
        // Asigno los los privilegios y roles
        final List<GrantedAuthority> authorities = Arrays.stream(claims.get("roles").toString().split(","))
                .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role).map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
        // Se devuelve el usuario asignando los privilegios de las lineas anteriores
        return username != null ? new UsernamePasswordAuthenticationToken(username, null, authorities) : null;
    }

    /**
     * Metodo que sirve para validar el token
     * 
     * @param request Proporciona acceso a los datos de las cabeceras HTTP, cookies,
     *                parámetros pasados por el usuario,
     * @return se devuelve true cuando la expiracion del token no ha pasado
     */
    public boolean validateToken(HttpServletRequest request) {
        // compruebo el token
        String token = resolveToken(request);
        // devuelvo falso si es nulo
        if (token == null) {
            return false;
        }
        /// comprueba que el jwt es firmado que se compone por:
        // Codificación en Base64 de header.
        // Codificación en Base64 de payload.
        // Un secreto, establecido por la aplicación.
        Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
        // compuerbo que la el tiempo del token no ha expirado
        if (claims.getExpiration().before(new Date())) {
            return false;
        }
        return true;
    }

    /**
     * Metodo encargado de resolver el token
     * 
     * @param req Proporciona acceso a los datos de las cabeceras HTTP, cookies,
     *            parámetros pasados por el usuario,
     * @return devuelve el esquema de autenticacion http
     */
    private String resolveToken(HttpServletRequest req) {
        // Obtengo el header
        String bearerToken = req.getHeader(jwtHeaderString);
        // compruebo que el bearer no es nulo y que empieza con el prefijo de la
        // propiedad
        if (bearerToken != null && bearerToken.startsWith(jwtTokenPrefix)) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }

}
