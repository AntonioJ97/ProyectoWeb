import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {

  user: User = new User();
  errorMessage: string;
  /**
   * Constructor de la clase
   * @param userService Permite obtener el usuario actual
   * @param router Usado para navegar al login cuando se  desconecta el usuario
   */
  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {}
  /**
   * Metodo encargado de realizar el registro
   */
  register(): void {
    this.userService.register(this.user).subscribe(
      (data) => {
        this.router.navigate(['/login']);
      },
      (err) => {
        this.errorMessage = 'El Username ya existe';
      }
    );
  }
}
