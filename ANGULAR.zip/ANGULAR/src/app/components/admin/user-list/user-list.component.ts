import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { User } from 'src/app/model/user';
import { AdminService } from 'src/app/services/admin.service';
declare var $: any;
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
})
export class UserListComponent implements OnInit {
  //array de usuarios
  userList: Array<User>;
  //Tabla de datos de angular material
  dataSource: MatTableDataSource<User> = new MatTableDataSource();
  // Titulos de las clumnas de la tablas
  displayedColumns: string[] = ['id', 'name', 'username', 'action'];
  //Usuario Seleccionado
  selectedUser: User = new User();
  // mensaje de error que se lanzara al intentar al modificar o borrar un usuario
  errorMessage: string;
  // Mensaje informativo que se lanzara al al modificar o borrar un usuario
  infoMessage: string;
  // Uso la directiva de MatPaginator para usarla como paginacion de los usuarios
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //Directiva MatSort que se usara para ordenar por columna id, nombre o precio
  @ViewChild(MatSort) sort: MatSort;
  /**
   *
   *  Metodo constructor de la clase
   * @param adminService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   */
  constructor(private adminService: AdminService) {}
  /**
   * Metodo que se inicia justo despues del constructor
   */
  ngOnInit(): void {
    // Obtengo todos los usuarios
    this.findAllUsers();
  }
  /**
   * Metodo que se ejecuta cuando la vista del componente se ha inicializado por completo.
   */
  ngAfterViewInit(): void {
    // Asigno el orden seleccionado por el usuario
    this.dataSource.sort = this.sort;
    // Asigno la pagina selccionada por el usuario
    this.dataSource.paginator = this.paginator;
  }
  /**
   * Metodo que obtiene todos los usuarios
   */
  findAllUsers(): void {
    this.adminService.findAllUsers().subscribe((data) => {
      this.userList = data;
      this.dataSource.data = data;
    });
  }
  /**
   * Metodo que se lanza al momento de pulsar en el boton de editar un usuario
   */
  editUserRequest(user: User): void {
    this.selectedUser = user;
    $('#userModal').modal('show');
  }
  /**
   * Metodo para editar un usuario
   */
  editUser(): void {
    this.adminService.updateUser(this.selectedUser).subscribe(
      (data) => {
        //Obtengo el indice del usuario
        let itemIndex = this.userList.findIndex(
          (item) => item.id == this.selectedUser.id
        );
        // asigno al usuario con id del indice el usuario seleccionado
        this.userList[itemIndex] = this.selectedUser;
        // Asigno los nuevos datos del usuario a la tabla
        this.dataSource = new MatTableDataSource(this.userList);
        this.infoMessage = 'Usuario modificado correctamente';
        $('#userModal').modal('hide');
      },
      (err) => {
        if (err.status === 409) {
          this.errorMessage = 'El nombre de usuario debe ser unico.';
        } else {
          this.errorMessage = 'Error inesperado ocurrido';
        }
      }
    );
  }
  /**
   * Metodo que se lanza al momento de pulsar en el boton de eliminar un usuario
   * @param product a eliminar
   */
  deleteUserRequest(user: User): void {
    this.selectedUser = user;
    $('#deleteModal').modal('show');
  }
  /**
   * Metodo para eliminar un usuario
   */
  deleteUser(): void {
    this.adminService.deleteUser(this.selectedUser).subscribe(
      (data) => {
        //Obtengo el indice del usuario
        let itemIndex = this.userList.findIndex(
          (item) => item.id == this.selectedUser.id
        );
        // compruebo que el indice sea distinto de -1, si lo es, elimino el usuario
        if (itemIndex !== -1) {
          this.userList.splice(itemIndex, 1);
        }
        // Asigno los nuevos datos del usuario a la tabla
        this.dataSource = new MatTableDataSource(this.userList);
        this.infoMessage = 'Borrado realizado con exito';
        $('#deleteModal').modal('hide');
      },
      (err) => {
        this.errorMessage = 'Error inesperado ocurrido';
      }
    );
  }
}
