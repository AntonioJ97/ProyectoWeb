package com.proyecto.service;

import com.proyecto.model.Transaction;


import java.util.List;
/**
 * Interfaz que implementara la clase TransactionServiceImpl
 */
public interface TransactionService {
    Transaction saveTransaction(Transaction transaction);

    Long numberOfTransactions();

    List<Transaction> findAllTransactions();

    
}
