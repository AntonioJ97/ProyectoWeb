/**
 * Clase que almacenara los datos de los productos.
 */
export class Product {
  id: number;
  name = '';
  price = 0;
  units: number;
  description: string;
  dateLaunched: Date;
  language: string;
  genre: string;
  platform: string;
  imagen: string;
}
