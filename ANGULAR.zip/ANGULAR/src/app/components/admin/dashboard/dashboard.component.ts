import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  userCount: any = '';
  productCount: any = '';
  transactionCount: any = '';
  /**
   * Metodo constructor de la clase
   * @param adminService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   */
  constructor(private adminService: AdminService) {}
  /**
   * Metodo que se inicia justo despues del constructor
   */
  ngOnInit(): void {
    //Obtengo el numero de usuarios
    this.numberOfUsers();
    //Obtengo el numero de productos
    this.numberOfProducts();
    //Obtengo el numero de transacciones total
    this.numberOfTransactions();
  }
  /**
   * Metodo para obtener el numero de usuarios
   */
  numberOfUsers(): void {
    this.adminService.numberOfUsers().subscribe((data) => {
      this.userCount = data.response;
    });
  }
  /**
   * Metodo para obtener el numero de productos
   */
  numberOfProducts(): void {
    this.adminService.numberOfProducts().subscribe((data) => {
      this.productCount = data.response;
    });
  }
  /**
   * Metodo para obtener el numero de transacciones
   */
  numberOfTransactions(): void {
    this.adminService.numberOfTransactions().subscribe((data) => {
      this.transactionCount = data.response;
    });
  }
}
