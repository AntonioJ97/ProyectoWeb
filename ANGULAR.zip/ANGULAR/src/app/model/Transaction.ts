import {Product} from './product';
import {User} from './user';
/**
 * Clase que se encarga de la compra de productos
 */
export class Transaction {
  id: number;
  product: Product;
  user: User;
  purchaseDate: any;
}
