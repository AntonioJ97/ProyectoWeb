package com.proyecto.config;

import com.proyecto.jwt.JWTAuthorizationFilter;
import com.proyecto.jwt.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Clase que permite configurar el control de acceso http y encriptar la
 * contraseña de los usuarios
 * 
 * @Configuration: Anotación encargada de definir que la clase es una clase de
 *                 configuración para el framework
 * @EnableWebSecurity: Sirve para habilitar el soporte de seguridad web de
 *                     Spring Security y proporcionar la integración de Spring
 *                     MVC
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    // Autowired lo que permite realizar es busqueda de un objeto manejado (beans)
    // que implementen determinada interfaz para hacer referencia a él
    // Permitiendo no tener que crear una instancia nueva del objeto cada vez que se
    // necesite la funcionalidad de determinada clase
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    /*
     * Interfaz UserDetailsService se utiliza para recuperar datos relacionados con
     * el usuario. Que se utiliza en el meto configure 
     */
    @Autowired
    private UserDetailsService userDetailsService;

    /**
     * Metodo encargado de encriptar contraseñas
     * 
     * @return la forma de encriptación la cual se utilizará para encriptar la
     *         contraseña
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Metodo encargado de configurar las rutas para el control de acceso http
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // Autoriza las respuestas cors utilizando el puerto: localhost:8080 y
        // localhost:4200
        http.cors().and().authorizeRequests()
                // Rutas publicas de acceso
                .antMatchers("/resources/**", "/error", "/api/user/**").permitAll()
                // Ruta permitida para aquellos que tengan el rol de admin
                .antMatchers("/api/admin/**").hasRole("ADMIN")
                // Todas las rutas que faltan necesitaran autenticación
                .anyRequest().fullyAuthenticated().and()
                // Cerrará la sesion usando la ruta /api/user/logout
                .logout().permitAll().logoutRequestMatcher(new AntPathRequestMatcher("/api/user/logout", "POST")).and()
                // formulario para logear y ruta de login
                .formLogin().loginPage("/api/user/login").and()
                // Activar autenticacion basica
                .httpBasic().and()
                // desactivo el csrf que
                // es un tipo de protección que impide que un sitio web pudiera hacer peticiones
                // maliciosas a otro sitio web que fuese seguro
                .csrf().disable();
        // agrego un filtrado de jwt
        http.addFilter(new JWTAuthorizationFilter(authenticationManager(), jwtTokenProvider));
    }

    /**
     * Metodo encargado de encriptar la contraseña del usuario que se autentique en
     * la aplicacion
     * 
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(this.passwordEncoder());
    }

    /**
     * 
     */
    // Cross origin resource sharing.
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            /**
             * Metodo encargado de procesar las respuesta del CORS
            */
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*").allowedMethods("*");
            }
        };
    }
}
