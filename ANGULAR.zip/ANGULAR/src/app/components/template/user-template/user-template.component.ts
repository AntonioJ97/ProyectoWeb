import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from 'src/app/model/role';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user-template',
  templateUrl: './user-template.component.html',
  styleUrls: ['./user-template.component.css'],
})
export class UserTemplateComponent implements OnInit {
  // Propiedad donde se almacena el usuario logeado
  currentUser: User;
  /**
   * Constructor de la clase
   * @param userService  Permite obtener el usuario actual
   * @param router Router usado para redirigir al usuario para cuando se desconecte de la web
   */
  constructor(private userService: UserService, private router: Router) {
    //asigno a la variable el usuario logeado
    this.userService.currentUser.subscribe((data) => {
      this.currentUser = data;
    });
  }

  ngOnInit(): void {}
  //Metodo usado para cerrar la sesion del usuario
  logOut(): void {
    this.userService.logOut().subscribe((data) => {
      this.router.navigate(['/login']);
    });
  }
  //Metodo para comprobar si el usuario tiene el rol de administrador
  get isAdmin() {
    return this.currentUser && this.currentUser.role === Role.ADMIN;
  }
}
