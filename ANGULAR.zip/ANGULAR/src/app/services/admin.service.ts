import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user';
import { Product } from '../model/product';
//url que se usara para acceder a las rutas del controlador
const API_URL = 'http://localhost:8080/api/admin/';

@Injectable({
  providedIn: 'root',
})
/**
 * Servicio encargado de realizar los envios de datos al controlador de admins
 */
export class AdminService {
  //usuario actual
  currentUser: User;
  headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    // cabecera indicando el tipo de archivo a resolver, en este caso json
    this.headers = new HttpHeaders({
      authorization: 'Bearer ' + this.currentUser.token,
      'Content-Type': 'application/json; charset=UTF-8',
    });
  }
  /**
   * Metodo encargado de actualizar un usuario
   * @param user usuario a modificar
   */
  updateUser(user: User): Observable<any> {
    return this.http.put(API_URL + 'user-update', JSON.stringify(user), {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de eliminar un usuario
   * @param user usuario a borrar
   */
  deleteUser(user: User): Observable<any> {
    return this.http.post(API_URL + 'user-delete', JSON.stringify(user), {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de obtener todos los usuarios
   */
  findAllUsers(): Observable<any> {
    return this.http.get(API_URL + 'user-all', { headers: this.headers });
  }
  /**
   * Metodo que permite saber el numero total de usuarios
   */
  numberOfUsers(): Observable<any> {
    return this.http.get(API_URL + 'user-number', { headers: this.headers });
  }

  /**
   * Metodo encargado de agregar un nuevo producto
   * @param product producto a agregar a la base de datos
   */
  createProduct(product: Product): Observable<any> {
    return this.http.post(API_URL + 'product-create', JSON.stringify(product), {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de actualizar un producto
   * @param product producto a actualizar
   */
  updateProduct(product: Product): Observable<any> {
    return this.http.put(API_URL + 'product-update', JSON.stringify(product), {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de eliminar un producto
   * @param product producto a borrar
   */
  deleteProduct(product: Product): Observable<any> {
    return this.http.post(API_URL + 'product-delete', JSON.stringify(product), {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de obtener todos los productos
   */
  findAllProducts(): Observable<any> {
    return this.http.get(API_URL + 'product-all', { headers: this.headers });
  }
  /**
   * Metodo que permite saber el numero total de productos
   */
  numberOfProducts(): Observable<any> {
    return this.http.get(API_URL + 'product-number', { headers: this.headers });
  }

  /**
   * Metodo encargado de obtener todas las compras realizadas por los usuarios
   */
  findAllTransactions(): Observable<any> {
    return this.http.get(API_URL + 'transaction-all', {
      headers: this.headers,
    });
  }
  /**
   * Metodo encargado de obtener el numero total de compras
   */
  numberOfTransactions(): Observable<any> {
    return this.http.get(API_URL + 'transaction-number', {
      headers: this.headers,
    });
  }
}
