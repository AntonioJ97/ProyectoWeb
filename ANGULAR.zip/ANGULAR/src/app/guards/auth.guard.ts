import { Injectable } from '@angular/core';
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  // Usuario que se almacenara
  currentUser: User;
  /**
   * Constructor de la clase
   * @param route Ruta usada para obtener el parametro de la url
   * @param userService  Servicio encargado de obtener los datos de la base de datos usando el controller del spring
   */
  constructor(private router: Router, private userService: UserService) {
    this.userService.currentUser.subscribe((data) => {
      this.currentUser = data;
    });
  }
  /**
   * Metodo para comprobar si se podra tener acceso a una ruta o no
   * @param route
   * @param state
   */
  // tslint:disable-next-line: typedef
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.currentUser) {
      // se comprueba si el usuario tiene un rol restringido, por ejemplo si el usuario no tiene el rol de admin
      if (
        route.data.roles &&
        route.data.roles.indexOf(this.currentUser.role) === -1
      ) {
        //si no lo tiene se lanza la pagina de usuario sin autorizacion
        this.router.navigate(['/401']);
        return false;
      }
      // si lo tiene el usuario accederia a la ruta
      return true;
    }
    // si no esta logeado el usuario se abre la web de login
    this.router.navigate(['/login']);
    return false;
  }
}
