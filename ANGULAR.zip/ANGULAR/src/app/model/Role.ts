/**
 *
 * Enumeracion usado para asignar el rol al usuario
 *
 */
export enum Role {
  USER = 'USER',
  ADMIN = 'ADMIN',
}
