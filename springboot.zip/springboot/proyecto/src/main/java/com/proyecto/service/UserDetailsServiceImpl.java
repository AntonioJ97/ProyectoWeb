package com.proyecto.service;

import com.proyecto.model.User;
import com.proyecto.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

/**
 * Clase que se encarga de cargar un usuario para usarlo en la clase
 * webSecurityConfig
 * 
 * @Service: Indica a Spring que esta clase es un servicio
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Metodo encargado de cargar el usuario logeado
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Creo un objeto con el usuario indicado
        User user = userRepository.findByUsername(username).orElse(null);
        // compruebo que no sea nulo
        if (user == null) {
            throw new UsernameNotFoundException(username);
        }
        // Creo un objeto con el rol que tiene el usuario
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(user.getRole().name()));
        // Devuelvo el usuario con los datos del usuario creado
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                grantedAuthorities);
    }
}
