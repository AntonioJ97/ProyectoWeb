import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  // Usuario logeado
  user: User = new User();
  // mensaje de error que se lanzara al intentar logearse
  errorMessage: string;
  /**
   * Constructor de la clase
   * @param userService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   * @param router Usado para navegar a los detalles de un producto
   */
  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {}
  /**
   * Metodo encargado de realizar el login del usuario
   */
  login(): void {
    this.userService.login(this.user).subscribe(
      (data) => {
        this.router.navigate(['/profile']);
      },
      (err) => {
        this.errorMessage = 'Username o la password es incorrecta.';
      }
    );
  }
}
