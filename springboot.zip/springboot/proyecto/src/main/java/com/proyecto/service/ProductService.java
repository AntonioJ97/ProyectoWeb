package com.proyecto.service;

import com.proyecto.model.Product;

import java.util.List;

/**
 * Interfaz que implementara la clase ProductServiceImpl
 */
public interface ProductService {
    Product saveProduct(Product product);

    Product updateProduct(Product product);

    void deleteProduct(Long productId);

    Long numberOfProducts();

    List<Product> findAllProducts();
}
