package com.proyecto.model;

import lombok.Data;

import javax.persistence.*;

/**
 * Clase que almacena los usuarios Anotacion @Data: Es una anotacion que agrupa
 * metodos como los getters,setters,toString y Equals Anotación @Entity: Indica
 * a Spring que es una entidad de base de datos Anotación @Table: Gracias a Jpa
 * permite que se cree en la base de datos una tabla con el nombre user
 */
@Data
@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;
    // @Enumerated: Asigna que el rol va a ser un texto
    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Role role;
    // @Transient: Permite demarcar que es una variable temporal, esta expirara a
    // cada dia, esta no sera una columna de la tabla
    @Transient
    private String token;

    // Getters y setters
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return this.role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getToken() {
        return this.token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
