package com.proyecto.model;

/**
 * Enumeracion usado para asignar el rol al usuario
 */
public enum Role {
    USER, ADMIN
}
