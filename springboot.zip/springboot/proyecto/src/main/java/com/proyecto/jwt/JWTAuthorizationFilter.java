package com.proyecto.jwt;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Esta clase se encarga de hacer un filtro de solicitudes, permite inspeccionar
 * la solicitud de autenticación, permitiendo si dejarla pasar o no.
 */
public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

    private JwtTokenProvider jwtTokenProvider;

    /**
     * Constructor de la clase
     * 
     * @param authenticationManager Es el encargado de recuperar la información de
     *                              usuario que se está intentando loguear en el
     *                              sistema
     * @param tokenProvider
     */
    public JWTAuthorizationFilter(AuthenticationManager authenticationManager, JwtTokenProvider tokenProvider) {
        super(authenticationManager);
        jwtTokenProvider = tokenProvider;
    }

    /**
     * Esta función será ejecutada cada vez que se realiza una petición HTTP. En
     * ella es donde podremos ver el contenido de la petición HTTP, en el objeto
     * ServletRequest y modificar la respuesta en el objeto ServletResponse .
     * FilterChain es lo que debemos ejecutar si queremos continuar la petición.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Obtengo el usuario autenticado
        Authentication authentication = jwtTokenProvider.getAuthentication(request);
        // compruebo que el token este correcto
        if (authentication != null && jwtTokenProvider.validateToken(request)) {
            // asigno el usuario al contexto a la aunteticacion
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }
        // pasamos el control de la peticion
        chain.doFilter(request, response);
    }
}
