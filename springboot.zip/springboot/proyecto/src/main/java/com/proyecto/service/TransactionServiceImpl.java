package com.proyecto.service;

import com.proyecto.model.Transaction;
import com.proyecto.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Clase encargada de agregar a la base de datos las compras
 * 
 * @Service: Indica a Spring que esta clase es un servicio
 * @Transactional: Permite realizar las transacciones con la base de datos
 */
@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    /**
     * Metodo que guarda la compra en la base de datos
     */
    @Override
    public Transaction saveTransaction(final Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    /**
     * Metodo que obtiene el numero de compras totales de la base de datos
     */
    @Override
    public Long numberOfTransactions() {
        return transactionRepository.count();
    }

    /**
     * Metodo que obtiene todas las compras de la base de datos
     */
    @Override
    public List<Transaction> findAllTransactions() {
        return transactionRepository.findAll();
    }

}
