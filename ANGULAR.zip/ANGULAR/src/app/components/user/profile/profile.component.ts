import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';
import { Transaction } from '../../../model/Transaction';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {

  current: number = 1;

  // Usuario que se almacenara
  currentUser: User;
  //Lista de transacciones
  transactionList: Array<Transaction>;
  // lista de transacciones del usuario
  transactionUser: Array<Transaction> = new Array();
  /**
   * Constructor de la clase
   * @param userService Permite obtener el usuario actual
   * @param router Usado para navegar al login cuando se  desconecta el usuario
   */
  constructor(private userService: UserService, private router: Router) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }
  /**
   * Metodo lanzado justo despues del constructor
   */
  ngOnInit(): void {
    this.findAllTransactions();
  }
  /**
   * Metodo que se lanza al desconectarse el usuario
   */
  logOut(): void {
    this.userService.logOut().subscribe((data) => {
      this.router.navigate(['/login']);
    });
  }
  /**
   * Metodo para obtener todas las compras de un usuario
   */
  findAllTransactions(): void {
    this.userService.findAllTransactions().subscribe((data) => {
      this.transactionList = data;
      this.transactionList.forEach((value) => {
        //compruebo que el id del usuario es igual al del usuario conectado
        if (value.user.id === this.currentUser.id) {
          //agrego los datos de las compras al array
          this.transactionUser.push(value);
        }
      });
    });
  }
  
}
