package com.proyecto.controller;

import com.proyecto.model.Product;
import com.proyecto.model.StringResponse;
import com.proyecto.model.User;
import com.proyecto.service.ProductService;
import com.proyecto.service.TransactionService;
import com.proyecto.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Clase encargada de controlar las rutas de los administradores Anotacion
 * encargada de indicar a spring que la clase es un controlador
 */
@RestController
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private ProductService productService;

    @Autowired
    private TransactionService transactionService;

    /**
     * Metodo encargado de actualizar los datos de un usuario
     * 
     * @param user Usuario a actualizar
     * @return Devuelve la respuesta que mandariamos al buscador en este caso a
     *         angular
     */
    @PutMapping("/api/admin/user-update")
    public ResponseEntity<?> updateUser(@RequestBody User user) {
        // Obtengo el usuario para comprobar que el usuario exista
        User existUser = userService.findByUsername(user.getUsername());
        // compruebo que el usuario exista
        if (existUser != null && !existUser.getId().equals(user.getId())) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>(userService.updateUser(user), HttpStatus.CREATED);
    }

    /**
     * Metodo encargado de eliminar a un usuario
     * 
     * @param user Usuario a eliminar
     * @return Devuelve la respuesta a angular
     */
    // This can be also @DeleteMapping.
    @PostMapping("/api/admin/user-delete")
    public ResponseEntity<?> deleteUser(@RequestBody User user) {
        // borro el usuario 
        userService.deleteUser(user.getId());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Metodo encargado de obtener todos los usuarios de la base de datos
     * 
     * @return Devuelve la respuesta que obtendra angular
     */
    @GetMapping("/api/admin/user-all")
    public ResponseEntity<?> findAllUsers() {
        return new ResponseEntity<>(userService.findAllUsers(), HttpStatus.OK);
    }

    /**
     * Obtiene el numero de usuarios de la base de datos
     * 
     * @return Devuelve la respuesta que obtendra angular
     */
    @GetMapping("/api/admin/user-number")
    public ResponseEntity<?> numberOfUsers() {
        Long number = userService.numberOfUsers();
        StringResponse response = new StringResponse();
        response.setResponse(number.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Metodo encargado de agregar un producto
     * 
     * @param product Producto a agregar
     * @return Devuelve la respuesta a angular
     */
    @PostMapping("/api/admin/product-create")
    public ResponseEntity<?> createProduct(@RequestBody Product product) {
        return new ResponseEntity<>(productService.saveProduct(product), HttpStatus.CREATED);
    }

    /**
     * Metodo encargado de actulizar un producto
     * 
     * @param product Producto a actualizar
     * @return Devuelve la respuesta a angular
     */
    @PutMapping("/api/admin/product-update")
    public ResponseEntity<?> updateProduct(@RequestBody Product product) {
        return new ResponseEntity<>(productService.updateProduct(product), HttpStatus.CREATED);
    }

    /**
     * Metodo encargado de eliminar un producto
     * 
     * @param product Producto a eliminar
     * @return Devuelve la respuesta a angular
     */
    @PostMapping("/api/admin/product-delete")
    public ResponseEntity<?> deleteProduct(@RequestBody Product product) {
        productService.deleteProduct(product.getId());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Metodo encargado de devolver todos los productos
     * 
     * @return Devuelve la respuesta a angular
     */
    @GetMapping("/api/admin/product-all")
    public ResponseEntity<?> findAllProducts() {
        return new ResponseEntity<>(productService.findAllProducts(), HttpStatus.OK);
    }

    /**
     * Metodo encargado de contar el numero de productos totales de la base de datos
     * 
     * @return devuelve la respuesta a angular
     */
    @GetMapping("/api/admin/product-number")
    public ResponseEntity<?> numberOfProducts() {
        Long number = productService.numberOfProducts();
        StringResponse response = new StringResponse();
        response.setResponse(number.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Metodo encargado de obtener todas las transacciones
     * 
     * @return devuelve la respuesta a angular
     */
    @GetMapping("/api/admin/transaction-all")
    public ResponseEntity<?> findAllTransactions() {
        return new ResponseEntity<>(transactionService.findAllTransactions(), HttpStatus.OK);
    }

    /**
     * Metodo encargado de devolver el numero de transacciones
     * 
     * @return devuelve la respuesta a angular
     */
    @GetMapping("api/admin/transaction-number")
    public ResponseEntity<?> numberOfTransactions() {
        Long number = transactionService.numberOfTransactions();
        StringResponse response = new StringResponse();
        response.setResponse(number.toString());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
