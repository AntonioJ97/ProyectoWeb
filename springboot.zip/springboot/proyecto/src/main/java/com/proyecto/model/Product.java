package com.proyecto.model;

import lombok.Data;

import java.util.Date;

import javax.persistence.*;

/**
 * Clase que almacenara los datos de los productos. Anotacion @Data: Es una
 * anotacion que agrupa metodos como los getters,setters,toString y Equals
 * Anotación @Entity: Indica a Spring que es una entidad de base de datos
 * Anotación @Table: Gracias a Jpa permite que se cree en la base de datos una
 * tabla con el nombre producto
 */
@Data
@Entity
@Table(name = "product")
public class Product {
    // @Id: indica a la base de datos que es la clave primaria
    // @GenerateValue: Indica a la base de datos que realice un incremento a cada
    // producto que se agregue a la base de datos
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "name")
    private String name;

    @Column(name = "price")
    private Double price;

    @Column(name = "units")
    private int units;

    @Column(name = "description")
    private String description;

    @Column(name = "date_launched")
    private Date dateLaunched;

    @Column(name = "language")
    private String language;

    @Column(name = "genre")
    private String genre;

    @Column(name = "platform")
    private String platform;

    @Column(name = "imagen")
    private String imagen;

    // Metodos getters y Setters
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return this.price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public int getUnits() {
        return this.units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateLaunched() {
        return this.dateLaunched;
    }

    public void setDateLaunched(Date dateLaunched) {
        this.dateLaunched = dateLaunched;
    }

    public String getLanguage() {
        return this.language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getGenre() {
        return this.genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPlatform() {
        return this.platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getImagen() {
        return this.imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

}
