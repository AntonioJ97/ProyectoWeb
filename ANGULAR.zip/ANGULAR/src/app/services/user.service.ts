import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../model/user';
import { Transaction } from '../model/transaction';

const API_URL = 'http://localhost:8080/api/user/';

@Injectable({
  providedIn: 'root',
})
/**
 * Servicio encargado de realizar los envios de datos al controlador de usuario
 */
export class UserService {
  // Variable en la cual se almacena el usuario usando el subject
  public currentUser: Observable<User>;
  /*
  Los subjects permiten compartir el mismo strema de datos sin tener el cuenta el tipo de observable
  */
  // variable en la cual se almacena el usuario del almacen
  private currentUserSubject: BehaviorSubject<User>;
  /**
   * constructor del servicio
   * @param http permite comunicarse con el servidor
   */
  constructor(private http: HttpClient) {
    // almaceno el usuario
    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem('currentUser'))
    );
    // asigno el usuario logeado como observable
    this.currentUser = this.currentUserSubject.asObservable();
  }
  // metodo para obtener el usuario conectado
  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }
  /**
   * Metodo que se encarga de realizar el login
   * @param user usuario a logearse
   */
  login(user: User): Observable<any> {
    const headers = new HttpHeaders(
      user
        ? {
            //permite codificar o descodificar la contraseña del usuario
            authorization: 'Basic ' + btoa(user.username + ':' + user.password),
          }
        : {}
    );
    //
    return this.http
      .get<any>(API_URL + 'login', { headers })
      .pipe(
        map((response) => {
          //compruebo que la respuesta llegue rellena si llega asigno el usuario
          if (response) {
            localStorage.setItem('currentUser', JSON.stringify(response));
            this.currentUserSubject.next(response);
          }
          return response;
        })
      );
  }
  /**
   * Metodo que permite desloguear a un usuario de la web
   */
  logOut(): Observable<any> {
    return this.http.post(API_URL + 'logout', {}).pipe(
      map((response) => {
        // remuevo el item del navegador para que no haya usuario logeado
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
      })
    );
  }
  /**
   * Metodo encargado de realizar el registro de usuario
   * @param user usuario a registrar
   */
  register(user: User): Observable<any> {
    return this.http.post(API_URL + 'registration', JSON.stringify(user), {
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    });
  }
  /**
   * Metodo encargado de obtener todos los productos del servidor
   */
  findAllProducts(): Observable<any> {
    return this.http.get(API_URL + 'products', {
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    });
  }
  /**
   * Metodo encargado de mandar la transacion al servidor para que lo agregue a la base de datos
   * @param transaction transaccion a enviar al servidor
   */
  purchaseProduct(transaction: Transaction): Observable<any> {
    return this.http.post(API_URL + 'purchase', JSON.stringify(transaction), {
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    });
  }

  /**
   * Metodo que obtiene todas las transacciones del servidor
   */
  findAllTransactions(): Observable<any> {
    return this.http.get(API_URL + 'transaction-all', {
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    });
 }
}
