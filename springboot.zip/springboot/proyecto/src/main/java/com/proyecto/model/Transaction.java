package com.proyecto.model;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Clase que se encarga de la compra de productos Anotacion @Data: Es una
 * anotacion que agrupa metodos como los getters,setters,toString y Equals
 * Anotación @Entity: Indica a Spring que es una entidad de base de datos
 * Anotación @Table: Gracias a Jpa permite que se cree en la base de datos una
 * tabla con el nombre transaction
 */
@Data
@Entity
@Table(name = "transaction")
public class Transaction {
    // @Id: indica a la base de datos que es la clave primaria
    // @GenerateValue: Indica a la base de datos que realice un incremento a cada
    // producto que se agregue a la base de datos
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    // @ManyToOne: crea la columna creando la relacion con el id del producto,
    // Utilizando el modelo entidad relacion: 1 a N
    // @JoinColumn: Crea una columna en la tabla con el id del producto
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", referencedColumnName = "id")
    private Product product;
    // @ManyToOne: crea la columna creando la relacion con el id del usuario,
    // Utilizando el modelo entidad relacion: 1 a N
    // @JoinColumn: Crea una columna en la tabla con el id del usuario
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;
    @Column(name = "purchase_date")
    private LocalDateTime purchaseDate;

    // Metodos getters setters
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Product getProduct() {
        return this.product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getPurchaseDate() {
        return this.purchaseDate;
    }

    public void setPurchaseDate(LocalDateTime purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

}
