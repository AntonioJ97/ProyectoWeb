import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Product } from 'src/app/model/product';
import { Transaction } from 'src/app/model/transaction';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  // Uso la directiva de MatPaginator para usarla como paginacion de los usuarios
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //array de productos
  productList: Array<Product>;
  //Tabla de datos de angular material
  dataSource: MatTableDataSource<Product> = new MatTableDataSource();
  // Array de datos usando observables
  //Los observables son un patron que básicamente nos ahorra tener que hacer consultas repetitivas de acceso a la fuente de información,
  //aumentando el rendimiento de las aplicaciones.
  obs: Observable<any>;
  // mensaje de error que se lanzara al intentar comprar un producto
  errorMessage: string;
  // Mensaje informativo que se lanzara al comprar un producto
  infoMessage: string;
  //Propiedad para comprobar que el usuario esta logeado para poder realizar la compra
  currentUser: User;
  /**
   * Constructor de la clase
   * @param userService Permite obtener el usuario actual
   * @param router Usado para navegar a los detalles de un producto
   * @param cdr Permite saber cuando se ha realizado algun cambio a la tabla de angular indicarlo y agregar los cambios
   */
  constructor(
    private userService: UserService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    // Obtengo el usuario logeado
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }
  /**
   * Metodo que se lanza justo despues del constructor
   */
  ngOnInit(): void {
    //metodo llamado para obtener todos los productos
    this.findAllProducts();
    // Asigno al observable los datos de la tabla
    this.obs = this.dataSource.connect();
  }
  /**
   * Metodo que se ejecuta cuando la vista del componente se ha inicializado por completo.
   */
  // tslint:disable-next-line: use-lifecycle-interface
  ngAfterViewInit(): void {
    // Asigno la pagina selccionada por el usuario
    this.dataSource.paginator = this.paginator;
    // Detecto los cambios, ya que al cambiar de pagina
    this.cdr.detectChanges();
  }

  /**
   * Se destruye el componente en el momento que se cambia de pagina de la web para mejorar el rendimiento
   */
  // tslint:disable-next-line: use-lifecycle-interface
  ngOnDestroy(): void {
    // Compruebo si el data source tiene datos, si los tiene los desconecto
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
  }

  /**
   * Metodo para obtener todos los productos de la base de datos
   */
  findAllProducts(): void {
    this.userService.findAllProducts().subscribe((data) => {
      this.productList = data;
      this.dataSource.data = data;
    });
  }
  /**
   * Metodo encargado de realizar la compra de un producto
   * @param product producto a comprar
   */
  purchaseProduct(product: Product): void {
    //compruebo si el usuario esta logeado
    if (!this.currentUser) {
      this.errorMessage = 'Necesitas estar registrado para comprar';
      return;
    }
    // creo la transaccion
    const transaction = new Transaction();
    //asigno el producto a la transaccion
    transaction.product = product;
    // asigno el usuario a la transaccion
    transaction.user = this.currentUser;
    /**
     * lanzo el metodo encargado de realizar la compra
     * */
    this.userService.purchaseProduct(transaction).subscribe(
      (data) => {
        this.infoMessage = 'Compra realizada. Tu Codigo es: ' + this.generarCodigoAleatorio();
      },
      (err) => {
        this.errorMessage = 'Error inesperado acaba de ocurrir';
      }
    );
  }
  /**
   * Metodo encargado de poder ver los detalles de un producto
   * @param product  producto a visualizar
   */
  detail(product: Product): void {
    //asigno el item al almacen local, y paso el producto
    localStorage.setItem('currentProduct', JSON.stringify(product));
    // realizo el routing pasando el id del producto
    this.router.navigate(['/detail', product.id]);
  }
  /**
   * Metodo encargado de realizar el filtro de busqueda por nombre del producto
   * @param filterValue Valor a buscar
   */
  // tslint:disable-next-line: typedef
  applyFilter(filterValue: string) {
    // remuevo los espacios en blanco
    filterValue = filterValue.trim();
    // transformo todo a minuscula
    filterValue = filterValue.toLowerCase();
    // realizo el filtrado
    this.dataSource.filter = filterValue;
  }
  /**
   * Metodo para generar un codigo aleatorio
   */
  generarCodigoAleatorio(): string{
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for (let i = 0; i < 16; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
        if(result.length % 4 == 0){
          result += '-'
        }
    }
    return result;
  }
}
