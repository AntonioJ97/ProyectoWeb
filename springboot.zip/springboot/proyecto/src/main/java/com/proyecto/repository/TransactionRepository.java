package com.proyecto.repository;

import com.proyecto.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Interfaz usada para los servicios las cuales permitirá realizar la
 * actualizacion,eliminacion o agregacion de la transaccion
 * El Long hace referencia al tipo de dato del id de la transaccion
 */
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}
