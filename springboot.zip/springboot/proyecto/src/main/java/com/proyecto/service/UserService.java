package com.proyecto.service;

import com.proyecto.model.User;

import java.util.List;

/**
 * Interfaz que implementara la clase UserServiceImpl
 */
public interface UserService {
    User saveUser(User user);

    User updateUser(User user);

    void deleteUser(Long userId);

    User findByUsername(String username);

    List<User> findAllUsers();

    Long numberOfUsers();
}
