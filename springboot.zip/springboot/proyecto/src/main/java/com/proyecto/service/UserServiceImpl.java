package com.proyecto.service;

import com.proyecto.model.User;
import com.proyecto.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Clase encargada de agregar a la base de datos los usuarios, modificar y
 * eliminar los usuarios de la base de datos
 * 
 * @Service: Indica a Spring que esta clase es un servicio
 * @Transactional: Permite realizar las transacciones con la base de datos
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    // It will be provided on WebSecurityConfig as @Bean
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Metodo para agregar un usuario a la base de datos
     */
    @Override
    public User saveUser(final User user) {
        // encripto la contraseña del usuario
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    /**
     * Metodo para modificar un usuario
     */
    @Override
    public User updateUser(final User user) {
        return userRepository.save(user);
    }

    /**
     * Metodo para eliminar un usuario
     */
    @Override
    public void deleteUser(final Long userId) {
        userRepository.deleteById(userId);
    }

    /**
     * Metodo para encontrar a un usuario en la base de datos usando el nombre
     */
    @Override
    public User findByUsername(final String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    /**
     * Metodo para obtener todos los usuarios de la base de datos
     */
    @Override
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Metodo para obtener el numero total de usuarios de la base de datos
     */
    @Override
    public Long numberOfUsers() {
        return userRepository.count();
    }

}
