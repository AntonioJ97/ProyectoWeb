import { Component } from '@angular/core';
import { Router, RoutesRecognized } from '@angular/router';
import { Role } from './model/role';
import { User } from './model/user';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Angular Proyecto';
  // usuario logeado
  currentUser: User;
  // boleando para cuando el usuario logeado es admin
  isAdminPanel = false;
  /**
   * Constructor de la clase
   * @param userService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   * @param router usado para obtener los roles del usuario
   */
  constructor(private userService: UserService, private router: Router) {
    this.userService.currentUser.subscribe((data) => {
      this.currentUser = data;
      this.userChanged();
    });
  }
  /**
   * Metodo encargado de obtener el tipo de rol del usuario
   */
  userChanged() {
    // compruebo que el usuario este logeado o tenga rol de admin, si no lo es o no esta logeado dejo el panel de admin en false
    if (!this.currentUser || Role.ADMIN !== this.currentUser.role) {
      this.isAdminPanel = false;
      return;
    }

    this.router.events.subscribe((evt) => {
      // compruebo que el evento tiene rutas reconocidad del archivo routing
      if (evt instanceof RoutesRecognized) {
        // asigno los roles
        const roles = evt.state.root.firstChild.data.roles;
        // compruebo que roles tenga datos y busco el rol del usuario y 
        //si es distinto de menos 1 quiere decir que el rol del usuario es administrador
        if (roles && roles.indexOf(this.currentUser.role) !== -1) {
          this.isAdminPanel = true;
        }
      }
    });
  }
}
