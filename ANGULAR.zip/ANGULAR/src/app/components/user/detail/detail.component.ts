import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/model/product';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css'],
})
export class DetailComponent implements OnInit {
  // Id del producto que se almacenara al recibirlo como parametro
  productId: string;
  // Producto que fue seleccionado
  currentProduct: Product;
  /**
   * Constructor de la clase
   * @param route Ruta usada para obtener el parametro de la url
   */
  constructor(private route: ActivatedRoute) {
    this.currentProduct =
      /* Este metodo permite realizar un parseo del producto
     guardado en el almacen local del navegador obteniendo el producto seleccionado,
      que se manda desde el componente home del usuario */
      JSON.parse(localStorage.getItem('currentProduct'));
  }
  /**
   * Metodo que se lanza justo despues del constructor
   */
  ngOnInit(): void {
    //Metodo encargado de obtener el id que se pasa por los parametros de la ruta
    this.route.paramMap.subscribe((params) => {
      //compruebo si tiene el parametro id seteado,y si lo esta asigno el id a la propiedad
      if (params.has('id')) {
        this.productId = params.get('id');
      }
    });
  }
}
