import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unathorized',
  templateUrl: './unathorized.component.html',
  styleUrls: ['./unathorized.component.css']
})
export class UnathorizedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
