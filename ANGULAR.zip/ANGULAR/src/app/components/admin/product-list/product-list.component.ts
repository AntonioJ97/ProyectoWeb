import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Product } from 'src/app/model/product';
import { AdminService } from 'src/app/services/admin.service';
declare var $: any;

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {
  //array de productos
  productList: Array<Product>;
  //Tabla de datos de angular material
  dataSource: MatTableDataSource<Product> = new MatTableDataSource();
  // Titulos de las clumnas de la tablas
  displayedColumns: string[] = ['id', 'nombre', 'precio', 'acciones'];
  // Obtener el producto seleccionado
  selectedProduct: Product = new Product();
  // mensaje de error que se lanzara al intentar crear un producto, modificarlo o borrarlo
  errorMessage: string;
  // Mensaje informativo que se lanzara al crear un producto,modificarlo o borrarlo
  infoMessage: string;
  // Uso la directiva de MatPaginator para usarla como paginacion de los productos
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //Directiva MatSort que se usara para ordenar por columna id, nombre o precio
  @ViewChild(MatSort) sort: MatSort;
  /**
   *
   *  Metodo constructor de la clase
   * @param adminService servicio encargado de obtener los datos de la base de datos usando el controller del spring
   */
  constructor(private adminService: AdminService) {}
  /**
   * Metodo que se inicia justo despues del constructor
   */
  ngOnInit(): void {
    // Obtengo todos los productos
    this.findAllProducts();
  }

  /**
   * Metodo que se ejecuta cuando la vista del componente se ha inicializado por completo.
   */
  ngAfterViewInit(): void {
    // Asigno el orden seleccionado por el usuario
    this.dataSource.sort = this.sort;
    // Asigno la pagina selccionada por el usuario
    this.dataSource.paginator = this.paginator;
  }
  /**
   * Metodo que obtiene todos los productos
   */
  findAllProducts(): void {
    this.adminService.findAllProducts().subscribe((data) => {
      //Asigno todos los productos al array
      this.productList = data;
      // Asigno todos los productos a la tabla de datos
      this.dataSource.data = data;
    });
  }
  /**
   * Metodo que se lanza al momento de pulsar en el boton de crear un producto
   */
  createNewProductRequest(): void {
    // Asigno un nuevo producto al producto seleccionado
    this.selectedProduct = new Product();
    $('#productModal').modal('show');
  }
  /**
   * Metodo que se lanza al momento de pulsar en el boton de modificar un producto
   * @param product a modificar
   */
  editProductRequest(product: Product): void {
    this.selectedProduct = product;
    $('#productModal').modal('show');
  }
  /**
   * Metodo para guardar un producto,
   */
  saveProduct(): void {
    //compruebo el id del producto seleccionado,
    //si tiene asignado un producto lo modifico, si no tiene asignado producto creo uno nuevo
    if (!this.selectedProduct.id) {
      this.createProduct();
    } else {
      this.updateProduct();
    }
  }
  /**
   * Metodo para crear un producto
   */
  createProduct(): void {
    this.adminService.createProduct(this.selectedProduct).subscribe(
      (data) => {
        //agrego el nuevo producto al array de productos
        this.productList.push(data);
        // Asigno los nuevos productos a la tabla
        this.dataSource = new MatTableDataSource(this.productList);
        this.infoMessage = 'Producto creado correctamente';
        //cierro el modal
        $('#productModal').modal('hide');
      },
      (err) => {
        //Lanzo el mensaje de error
        this.errorMessage = 'Error inesperado ocurrido';
      }
    );
  }
  /**
   * Metodo para actualizar un producto
   */
  updateProduct(): void {
    this.adminService.updateProduct(this.selectedProduct).subscribe(
      (data) => {
        //Obtengo el indice del producto
        const itemIndex = this.productList.findIndex(
          (item) => item.id === this.selectedProduct.id
        );
        // asigno al producto con id del indice el producto seleccionado
        this.productList[itemIndex] = this.selectedProduct;
        // Asigno los nuevos datos del producto a la tabla
        this.dataSource = new MatTableDataSource(this.productList);
        this.infoMessage = 'Producto modificado correctamente';
        //cierro el modal
        $('#productModal').modal('hide');
      },
      (err) => {
        //Lanzo el mensaje de error
        this.errorMessage = 'Error inesperado ocurrido';
      }
    );
  }
   /**
   * Metodo que se lanza al momento de pulsar en el boton de eliminar un producto
   * @param product a eliminar
   */
  deleteProductRequest(product: Product): void {
    //asigno el producto seleccionado y lanzo el modal
    this.selectedProduct = product;
    $('#deleteModal').modal('show');
  }
  /**
   *  Metodo para borrar el producto
   */
  deleteProduct(): void {
    this.adminService.deleteProduct(this.selectedProduct).subscribe(
      (data) => {
        //Obtengo el indice del producto
        const itemIndex = this.productList.findIndex(
          (item) => item.id === this.selectedProduct.id
        );
        // compruebo que el indice sea distinto de -1, si lo es, elimino el producto
        if (itemIndex !== -1) {
          this.productList.splice(itemIndex, 1);
        }
        // Asigno los nuevos datos del producto a la tabla
        this.dataSource = new MatTableDataSource(this.productList);
        this.infoMessage = 'Producto eliminado correctamente';
        //cierro el modal
        $('#deleteModal').modal('hide');
      },
      (err) => {
        //Lanzo el mensaje de error
        this.errorMessage = 'Error inesperado ocurrido';
      }
    );
  }
}
